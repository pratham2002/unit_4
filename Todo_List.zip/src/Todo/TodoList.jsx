import { useDispatch, useSelector } from "react-redux";
import { toggleTodo } from "../redux/actions";

function TodoItem({ id, title, status }) {
  const dispatch = useDispatch();
  const handleToggle = (id) => {
    const action = toggleTodo(id);
    dispatch(action);
  };
  return (
    <div
      style={{
        cursor: "pointer",
        display: "flex",
        padding: "1rem",
        gap: "2rem"
      }}
    >
      <div onClick={() => handleToggle(id)}>{title}</div>
    </div>
  );
}

function TodoList() {
  const todos = useSelector((state) => state.todos);
  console.log(todos);
  return (
    <>
      <hr />
      <div>
        <h1>Pending</h1>
        {todos
          ?.filter((e) => !e.status)
          .map((item) => (
            <TodoItem key={item.id} {...item} />
          ))}
      </div>
      <hr />
      <h1>Completed</h1>
      <div style={{ textDecoration: "line-through" }}>
        {todos
          ?.filter((e) => e.status)
          .map((item) => (
            <TodoItem key={item.id} {...item} />
          ))}
      </div>
    </>
  );
}

export default TodoList;
