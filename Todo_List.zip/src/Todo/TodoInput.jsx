import { useState } from "react";

function TodoInput({ onAdd }) {
  const [state, setState] = useState("");

  return (
    <div>
      <input
        value={state}
        onChange={(e) => setState(e.target.value)}
        placeholder="Add something"
      />
      <button
        onClick={() => {
          if (state) {
            onAdd(state);
            setState("");
          } else {
            window.alert("Todo Can't Be Empty");
          }
        }}
      >
        ADD
      </button>
    </div>
  );
}

export default TodoInput;
