// constants
export const actionConstants = {
  ADD_TODO: "ADD_TODO",
  TOGGLE_TODO_STATUS: "TOGGLE_TODO_STATUS"
};

export const addTodo = ({ title, status, id }) => {
  return {
    type: actionConstants.ADD_TODO,
    payload: {
      title,
      status,
      id
    }
  };
};

export const toggleTodo = (id) => ({
  type: actionConstants.TOGGLE_TODO_STATUS,
  payload: {
    id: id
  }
});
