import "./styles.css";
import Todo from "./Todo/Todo";

export default function App() {
  return (
    <div className="App">
      <h1>Performance Optimisation</h1>
      <Todo />
    </div>
  );
}
